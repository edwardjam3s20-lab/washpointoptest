import { Booking, Washer, Transaction, WashStep, ServicePlan } from './types';

export const INITIAL_SERVICES: ServicePlan[] = [
  { id: 'SPLAN1', name: 'Single Wash', price: 650, duration: 15, description: 'High-pressure foam exterior wash, rim wipe, and tire gloss shine.' },
  { id: 'SPLAN2', name: 'Full Service', price: 1200, duration: 25, description: 'Single Wash + chassis rinse, interior vacuuming, dashboard polish, and air freshener.' },
  { id: 'SPLAN3', name: 'Unlimited', price: 800, duration: 15, description: 'Daily subscriber priority single wash treatment, fast-track queue pass.' },
  { id: 'SPLAN4', name: 'Fleet Wash', price: 2000, duration: 30, description: 'Large commercial SUV/van pristine high-foaming deep wash & luxury cabin interior detail.' }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'B1',
    user_name: 'Abdi Omar',
    initials: 'AO',
    plate: 'KDD 884X',
    time: '15:00',
    amount: 1200,
    status: 'Confirmed',
    plan: 'Full Service',
    duration: 20,
  },
  {
    id: 'B2',
    user_name: 'Siti Halima',
    initials: 'SH',
    plate: 'KCB 442A',
    time: '15:15',
    amount: 800,
    status: 'In Progress',
    plan: 'Unlimited',
    duration: 15,
    assignedWasherId: 'W1',
    washStartedAt: new Date(Date.now() - 6 * 60000).toISOString(), // 6 minutes ago
  },
  {
    id: 'B3',
    user_name: 'David Gitonga',
    initials: 'DG',
    plate: 'KDG 112L',
    time: '14:30',
    amount: 1500,
    status: 'Overdue',
    plan: 'Full Service',
    duration: 30,
  },
  {
    id: 'B4',
    user_name: 'Mary Atieno',
    initials: 'MA',
    plate: 'KDF 904K',
    time: '15:45',
    amount: 650,
    status: 'Confirmed',
    plan: 'Single Wash',
    duration: 15,
  },
  {
    id: 'B5',
    user_name: 'Johnstone Kiprop',
    initials: 'JK',
    plate: 'KCS 202W',
    time: '16:00',
    amount: 1200,
    status: 'Confirmed',
    plan: 'Full Service',
    duration: 25,
  }
];

export const INITIAL_WASHERS: Washer[] = [
  { id: 'W1', name: 'Brian Otieno', role: 'Senior Washer & QC', avatarColor: 'bg-blue-600 text-white' },
  { id: 'W2', name: 'Hamisi Bakari', role: 'Exterior Specialist', avatarColor: 'bg-emerald-600 text-white' },
  { id: 'W3', name: 'Mwangi Kamau', role: 'Detailing Pro', avatarColor: 'bg-pink-600 text-white' },
  { id: 'W4', name: 'Fatuma Juma', role: 'Finishing Inspector', avatarColor: 'bg-indigo-600 text-white' }
];

export const WASH_STEPS: WashStep[] = [
  { id: 'S1', title: 'Pre-rinse & undercarriage spraying', category: 'prep' },
  { id: 'S2', title: 'High-foaming active shampoo layer', category: 'wash' },
  { id: 'S3', title: 'Alloy rim detailing & tire pressure verify', category: 'wash' },
  { id: 'S4', title: 'Streak-free microfiber body wipe-down', category: 'dry' },
  { id: 'S5', title: 'Interior dashboard console dust & vacuum', category: 'dry' },
  { id: 'S6', title: 'Final QC shine check & signature', category: 'inspect' }
];

export const RECENT_TRANSACTIONS: Transaction[] = [
  { id: 'T1', user_name: 'Hassan Juma', type: 'Single Wash', amount: 650, time: '14:12', date: 'Today' },
  { id: 'T2', user_name: 'Grace Mwende', type: 'Full Service', amount: 1200, time: '13:40', date: 'Today' },
  { id: 'T3', user_name: 'Nicholas Odhiambo', type: 'Unlimited', amount: 800, time: '12:15', date: 'Today' },
  { id: 'T4', user_name: 'Peter Kamau', type: 'Fleet', amount: 2000, time: '10:30', date: 'Today' },
  { id: 'T5', user_name: 'Lorna Cherono', type: 'Single Wash', amount: 650, time: 'Yesterday', date: 'Yesterday' },
  { id: 'T6', user_name: 'Emily Kendi', type: 'Full Service', amount: 1200, time: 'Yesterday', date: 'Yesterday' },
  { id: 'T7', user_name: 'George Njoroge', type: 'Unlimited', amount: 800, time: '2 days ago', date: 'Older' },
  { id: 'T8', user_name: 'Nancy Wambui', type: 'Full Service', amount: 1200, time: '3 days ago', date: 'Older' }
];

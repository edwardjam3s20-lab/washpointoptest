import React, { useState, useEffect } from 'react';
import { 
  Home as HomeIcon, 
  QrCode, 
  Droplet, 
  TrendingUp, 
  MoreHorizontal, 
  Check, 
  Search, 
  Clock, 
  MapPin, 
  User, 
  Sparkles, 
  ChevronRight, 
  BarChart3, 
  RotateCcw, 
  ShieldCheck, 
  Award, 
  Info,
  DollarSign,
  Activity,
  UserCheck,
  Plus,
  Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

import { Booking, Washer, Transaction, WashStep, ServicePlan } from './types';
import { INITIAL_BOOKINGS, INITIAL_WASHERS, RECENT_TRANSACTIONS, WASH_STEPS, INITIAL_SERVICES } from './data';

export default function App() {
  // Mobile app tabs
  const [activeTab, setActiveTab] = useState<'Home' | 'Scan' | 'Wash' | 'Earnings' | 'More'>('Home');

  // Business state
  const [isBusinessOpen, setIsBusinessOpen] = useState(true);

  // Active bookings state
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);

  // Active washing ID
  const [activeBookingId, setActiveBookingId] = useState<string>('B2'); // Siti Halima initially washing

  // Washers track
  const [washers, setWashers] = useState<Washer[]>(INITIAL_WASHERS);

  // Completed steps tracker for each booking ID that goes into Wash In Progress
  const [stepsProgress, setStepsProgress] = useState<{ [bookingId: string]: string[] }>({
    B2: ['S1', 'S2', 'S3'], // Siti Halima has 3 steps checked initially (50%)
    B1: [],
    B3: [],
    B4: [],
    B5: []
  });

  // Countdown timers (seconds remaining) for in-progress bookings
  const [timers, setTimers] = useState<{ [bookingId: string]: number }>({
    B2: 540, // 9:00 remaining
    B1: 1200, // 20 mins
    B3: 1800,
    B4: 900,
    B5: 1500
  });

  // Scan screen states
  const [searchQuery, setSearchQuery] = useState('');
  const [recentScans, setRecentScans] = useState<Booking[]>([]);

  // Detailed Modal popup states
  const [verifiedBooking, setVerifiedBooking] = useState<Booking | null>(null);

  // General app interactions
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);
  const [earningsPeriod, setEarningsPeriod] = useState<'Week' | 'Month'>('Week');
  
  // Custom transaction history state
  const [transactions, setTransactions] = useState<Transaction[]>(RECENT_TRANSACTIONS);

  // Dynamic Services & Pricing List State
  const [services, setServices] = useState<ServicePlan[]>(INITIAL_SERVICES);

  // Incoming Booking Request Notification state
  const [incomingBooking, setIncomingBooking] = useState<Booking | null>(null);

  // Selected Washer helper during check-in/verification
  const [selectedWasherId, setSelectedWasherId] = useState<string>('');

  // Roster Sub-Modals Open states
  const [showWashersModal, setShowWashersModal] = useState(false);
  const [showServicesModal, setShowServicesModal] = useState(false);

  // Subscription management states
  const [operatorPlan, setOperatorPlan] = useState<'Starter' | 'Growth' | 'Pro'>('Pro');
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  // Edit Service working state template holder
  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  
  // New Staff inputs state
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState('Exterior Specialist');

  // Trigger loading selection washer update
  useEffect(() => {
    if (verifiedBooking) {
      setSelectedWasherId(verifiedBooking.assignedWasherId || washers[0]?.id || '');
    } else {
      setSelectedWasherId('');
    }
  }, [verifiedBooking, washers]);

  // Periodic automatic incoming booking request flow
  useEffect(() => {
    if (!isBusinessOpen) return;
    
    // Simulate real-time customer request arrive every 40-50 secs
    const interval = setInterval(() => {
      if (incomingBooking) return; // avoid overwriting active request
      
      const names = ["Karanja Kariuki", "Rehema Mwenda", "Amina Yusuf", "Faraji Mwangi", "Zuwena Juma", "Njuguna Njoroge"];
      const plates = ["KCD 119H", "KCY 992P", "KBZ 553T", "KDD 980J", "KCE 412F", "KCA 777Y"];
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomPlate = plates[Math.floor(Math.random() * plates.length)];
      
      const randomService = services[Math.floor(Math.random() * services.length)] || services[0];
      
      const newRequest: Booking = {
        id: 'REQ_' + Math.random().toString(36).substring(2, 6).toUpperCase(),
        user_name: randomName,
        initials: randomName.split(' ').map(n => n[0]).join(''),
        plate: randomPlate,
        time: 'Immediate',
        amount: randomService.price,
        plan: randomService.name,
        duration: randomService.duration,
        status: 'Confirmed'
      };
      
      setIncomingBooking(newRequest);
      showToast(`🔔 Live booking request received from ${randomName}!`, "info");
    }, 45000);
    
    return () => clearInterval(interval);
  }, [incomingBooking, services, isBusinessOpen]);

  // Trigger Toast helper
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  // Countdown timer clock tick effect
  useEffect(() => {
    const interval = setInterval(() => {
      setTimers((prev) => {
        const next = { ...prev };
        let updated = false;
        Object.keys(next).forEach((key) => {
          // decrement if that booking is actually in-progress
          const booking = bookings.find((b) => b.id === key);
          if (booking && booking.status === 'In Progress' && next[key] > 0) {
            next[key] = next[key] - 1;
            updated = true;
          }
        });
        return updated ? next : prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [bookings]);

  // Handle open/closed toggle
  const handleToggleOpenStatus = () => {
    const nextState = !isBusinessOpen;
    setIsBusinessOpen(nextState);
    showToast(
      nextState 
        ? "Coastline Car Wash is now OPEN. Customers can place bookings." 
        : "Coastline Car Wash is now CLOSED. Queue is paused.",
      nextState ? "success" : "info"
    );
  };

  // Up next / Check In action
  const handleCheckInBtnClick = (booking: Booking) => {
    setVerifiedBooking(booking);
  };

  // Confirm arrival/check-in inside verified bottom sheet modal
  const handleConfirmArrival = () => {
    if (!verifiedBooking) return;
    
    const finalWasherId = selectedWasherId || washers[0]?.id || '';
    const assignedWasher = washers.find(w => w.id === finalWasherId);

    // Update booking status from 'Confirmed' or 'Overdue' to 'In Progress'
    setBookings((prev) =>
      prev.map((b) =>
        b.id === verifiedBooking.id
          ? { ...b, status: 'In Progress', assignedWasherId: finalWasherId }
          : b
      )
    );

    // Ensure we track its timer
    if (!timers[verifiedBooking.id]) {
      setTimers((prev) => ({
        ...prev,
        [verifiedBooking.id]: verifiedBooking.duration * 60
      }));
    }

    // Set as the primary viewable wash in the "Wash" screen
    setActiveBookingId(verifiedBooking.id);
    
    // Notify operator
    showToast(`${verifiedBooking.user_name} checked in! Assigned to ${assignedWasher?.name || 'Staff'}.`, "success");
    
    // Close modal
    setVerifiedBooking(null);
    
    // Redirect to active Wash screen
    setActiveTab('Wash');
  };

  // Search/Scan plate simulation
  const handleSearchPlate = () => {
    const formatted = searchQuery.trim().toUpperCase();
    if (!formatted) {
      showToast("Please enter a plate number", "error");
      return;
    }

    // Find custom match in queue
    const match = bookings.find(
      (b) => b.plate.toUpperCase().includes(formatted) || formatted.includes(b.plate.toUpperCase())
    );

    if (match) {
      setVerifiedBooking(match);
      // add to recent lists
      if (!recentScans.some((b) => b.id === match.id)) {
        setRecentScans((prev) => [match, ...prev.slice(0, 3)]);
      }
      setSearchQuery('');
    } else {
      // create a mock guest booking using first active service model
      const activeSvc = services[0] || { name: 'Single Wash', price: 650, duration: 15 };
      const mockGuest: Booking = {
        id: 'BG_' + Math.random().toString(36).substring(2, 6).toUpperCase(),
        user_name: 'Guest Driver',
        initials: 'GD',
        plate: formatted,
        time: 'Immediate',
        amount: activeSvc.price,
        status: 'Confirmed',
        plan: activeSvc.name,
        duration: activeSvc.duration
      };
      
      // select it for verification
      setVerifiedBooking(mockGuest);
      // insert into queue to keep state integrated
      setBookings((prev) => [mockGuest, ...prev]);
      setSearchQuery('');
    }
  };

  const handleSimulateQRScan = (shortcutType?: 'B1' | 'B4' | 'B5') => {
    const targetId = shortcutType || 'B1';
    const booking = bookings.find((b) => b.id === targetId);
    if (booking) {
      setVerifiedBooking(booking);
      if (!recentScans.some((b) => b.id === booking.id)) {
        setRecentScans((prev) => [booking, ...prev.slice(0, 3)]);
      }
      showToast("QR code scanned successfully!", "success");
    } else {
      showToast("Booking not found or already completed", "error");
    }
  };

  // Toggle step checklist in Wash in Progress screen
  const toggleStepCompleted = (bookingId: string, stepId: string) => {
    setStepsProgress((prev) => {
      const current = prev[bookingId] || [];
      const updated = current.includes(stepId)
        ? current.filter((id) => id !== stepId)
        : [...current, stepId];
      return { ...prev, [bookingId]: updated };
    });
  };

  // Complete a wash and archive it
  const handleCompleteWash = (booking: Booking) => {
    // 1. Mark booking completed
    setBookings((prev) => prev.filter((b) => b.id !== booking.id));

    // 2. Add to transactions list
    const newTx: Transaction = {
      id: 'T_' + Date.now(),
      user_name: booking.user_name,
      type: booking.plan,
      amount: booking.amount,
      time: new Date().toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit', hour12: false }),
      date: 'Today'
    };
    setTransactions((prev) => [newTx, ...prev]);

    // 3. Trigger toast
    showToast(`✓ Comfort complete! ${booking.user_name} finished. KES ${booking.amount} collected.`, "success");

    // 4. Reset progress tracker and active washer
    setActiveBookingId('');

    // 5. Back to home tab
    setActiveTab('Home');
  };

  // Pick another booking to monitor
  const activeWashBooking = bookings.find((b) => b.id === activeBookingId && b.status === 'In Progress');

  // List of remaining bookings currently in-progress
  const inProgressList = bookings.filter((b) => b.status === 'In Progress');

  // Format countdown remaining timer (MM:SS)
  const formatTimer = (secondsRemaining: number) => {
    const mins = Math.floor(secondsRemaining / 60);
    const secs = secondsRemaining % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Compute stat card metrics
  const totalCarsToday = transactions.filter((t) => t.date === 'Today').length + bookings.filter((b) => b.status === 'Completed').length;
  const completedTodayList = transactions.filter((t) => t.date === 'Today');
  const revenueToday = completedTodayList.reduce((acc, current) => acc + current.amount, 0);

  // Dynamic Commission rates based on selected SaaS status tier:
  // - Starter: 20% commission (0/mo)
  // - Growth: 10% commission + 1,499/mo
  // - Pro: 0% commission + 2,999/mo
  const getCommissionRate = (plan: 'Starter' | 'Growth' | 'Pro'): number => {
    if (plan === 'Starter') return 0.20;
    if (plan === 'Growth') return 0.10;
    return 0.0; // Pro is 0% commission
  };

  const currentCommissionRate = getCommissionRate(operatorPlan);
  const operatorPercentage = 1 - currentCommissionRate;

  // Commission calculations: based on dynamic SaaS tier rates selected
  const operatorPortion = Math.round(revenueToday * operatorPercentage);
  const splashpassCommission = Math.round(revenueToday * currentCommissionRate);

  // Compute stats for weekly/monthly earnings
  const weeklyRevenue = transactions.reduce((acc, current) => acc + current.amount, 0) * operatorPercentage; 
  const monthlyRevenue = (transactions.reduce((acc, current) => acc + current.amount, 0) * 4.2) * operatorPercentage;

  // Render weekly dataset for Recharts
  const weeklyChartData = [
    { day: 'Mon', ksh: 4200, label: 'KES 4.2K' },
    { day: 'Tue', ksh: 5600, label: 'KES 5.6K' },
    { day: 'Wed', ksh: 3800, label: 'KES 3.8K' },
    { day: 'Thu', ksh: 6400, label: 'KES 6.4K' },
    { day: 'Fri', ksh: 7200, label: 'KES 7.2K' },
    { day: 'Sat', ksh: 9500, label: 'KES 9.5K' },
    { day: 'Sun', ksh: 8400, label: 'KES 8.4K' },
  ];

  const monthlyChartData = [
    { day: 'Week 1', ksh: 28000, label: 'KES 28K' },
    { day: 'Week 2', ksh: 34000, label: 'KES 34K' },
    { day: 'Week 3', ksh: 41000, label: 'KES 41K' },
    { day: 'Week 4', ksh: 49200, label: 'KES 49.2K' },
  ];

  const currentChartData = earningsPeriod === 'Week' ? weeklyChartData : monthlyChartData;

  return (
    <div className="w-full min-h-screen bg-slate-200 flex items-center justify-center p-4 overflow-y-auto font-sans">
      {/* Phone frame mockup: exactly 390×844px */}
      <div className="w-[390px] h-[844px] relative rounded-[40px] shadow-2xl border-8 border-slate-900 bg-slate-50 flex flex-col overflow-hidden select-none">
        
        {/* Top Camera cutout pill notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-32 h-4.5 bg-slate-900 rounded-full z-50 flex items-center justify-center">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-800 absolute right-4"></span>
        </div>

        {/* Status Bar simulation at top */}
        <div className={`h-10 px-6 pt-2.5 flex items-center justify-between z-40 transition-colors duration-300 ${activeTab === 'Home' ? 'bg-gradient-to-r from-blue-700 to-blue-600 text-white' : 'bg-white text-slate-800'}`}>
          <span className="font-title-small font-semibold">9:41</span>
          <div className="flex items-center gap-1.5 object-contain">
            {/* signal bars */}
            <div className="flex items-end gap-0.5 h-3">
              <span className={`w-0.5 h-1 rounded-full ${activeTab === 'Home' ? 'bg-white' : 'bg-slate-700'}`}></span>
              <span className={`w-0.5 h-1.5 rounded-full ${activeTab === 'Home' ? 'bg-white' : 'bg-slate-700'}`}></span>
              <span className={`w-0.5 h-2 rounded-full ${activeTab === 'Home' ? 'bg-white' : 'bg-slate-700'}`}></span>
              <span className={`w-0.5 h-2.5 rounded-full ${activeTab === 'Home' ? 'bg-white' : 'bg-slate-700'}`}></span>
            </div>
            {/* Wifi icons with circles */}
            <span className="font-caption !text-[10px] scale-110">📡</span>
            {/* Battery mockup */}
            <div className={`w-5.5 h-2.5 rounded-[4px] border ${activeTab === 'Home' ? 'border-white/80' : 'border-slate-700'} p-0.5 flex items-center`}>
              <div className={`h-full w-4 rounded-[2px] ${activeTab === 'Home' ? 'bg-white' : 'bg-slate-800'}`}></div>
            </div>
          </div>
        </div>

        {/* TOAST SYSTEM */}
        <AnimatePresence>
          {toast && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8, y: -20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: -20 }}
              className="absolute top-12 left-4 right-4 z-50 p-4 rounded-xl shadow-lg border backdrop-blur-md flex items-center gap-3 bg-white border-slate-100"
            >
              <div className={`w-2 h-2 rounded-full ${toast.type === 'error' ? 'bg-red-500' : toast.type === 'info' ? 'bg-amber-500' : 'bg-emerald-500'}`} />
              <p className="font-body-small-bold text-slate-700 flex-1">{toast.message}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* INCOMING BOOKING ALERT DRAWER / FLOATING NOTIFICATION SYSTEM */}
        <AnimatePresence>
          {incomingBooking && (
            <motion.div
              initial={{ opacity: 0, y: -100, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -60, scale: 0.95 }}
              transition={{ type: "spring", damping: 20, stiffness: 180 }}
              className="absolute top-12 left-4 right-4 z-50 bg-slate-900 border border-blue-500/30 text-white rounded-3xl p-4 shadow-2xl flex flex-col gap-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
                  </span>
                  <span className="text-[10px] font-bold font-caption text-amber-400 uppercase tracking-wider">Live Online Booking request</span>
                </div>
                <div className="bg-blue-900/40 text-blue-300 border border-blue-800/30 px-2 py-0.5 rounded-full text-[9px] font-bold font-micro">
                  INCOMING
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white/5 border border-white/5 rounded-2xl p-3">
                <div className="w-10 h-10 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-300 font-title-large text-sm font-black">
                  {incomingBooking.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h4 className="text-white text-sm font-bold font-title-medium truncate">{incomingBooking.user_name}</h4>
                    <span className="text-emerald-400 text-xs font-black font-caption whitespace-nowrap">KSh {incomingBooking.amount}</span>
                  </div>
                  <h3 className="text-blue-200 text-[13px] font-bold tracking-widest mt-0.5 font-display-small truncate">{incomingBooking.plate}</h3>
                  <div className="flex items-center gap-3 mt-1.5 text-slate-400 text-[11px] font-bold font-micro">
                    <span>✨ {incomingBooking.plan}</span>
                    <span className="w-1 h-1 rounded-full bg-slate-700"></span>
                    <span>⏱ {incomingBooking.duration}m duration</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-0.5">
                <button
                  onClick={() => {
                    showToast(`Dismissed booking request from ${incomingBooking.user_name}`, "error");
                    setIncomingBooking(null);
                  }}
                  className="bg-slate-800 hover:bg-slate-700 active:scale-[0.98] border border-slate-850 text-slate-300 font-bold font-body-small-bold py-2.5 rounded-xl text-xs transition-all cursor-pointer text-center"
                >
                  Decline & Dismiss
                </button>
                <button
                  onClick={() => {
                    // Update bookings state with incoming
                    setBookings((prev) => [incomingBooking, ...prev]);
                    showToast(`✓ Booking accepted! Added ${incomingBooking.user_name} to queue.`, "success");
                    setIncomingBooking(null);
                  }}
                  className="bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white font-bold font-body-small-bold py-2.5 rounded-xl text-xs shadow-md shadow-blue-500/20 transition-all cursor-pointer text-center"
                >
                  Accept Booking
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* PRIMARY VIEWPORT: 732px (844px height - 40px status - 72px footer) */}
        <div className="flex-1 overflow-y-auto hide-scrollbar flex flex-col bg-slate-50 pb-20">
          
          {/* SCREEN: HOME */}
          {activeTab === 'Home' && (
            <div className="flex flex-col flex-1">
              {/* Header: Blue-600 Gradient Banner from the Vibrant Palette Theme */}
              <div className="bg-gradient-to-br from-blue-600 to-blue-700 text-white p-6 pt-12 rounded-b-[32px] shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 -mr-16 -mt-16 w-52 h-52 bg-white/5 rounded-full blur-3xl pointer-events-none"></div>
                
                {/* Brand metadata following Mombasa visual aesthetic */}
                <div className="flex justify-between items-start mb-6">
                  <div className="space-y-0.5">
                    <p className="text-blue-100 text-xs font-semibold tracking-wide uppercase font-caption">COASTLINE CAR WASH</p>
                    <h2 className="text-white text-lg font-bold font-title-large">Mombasa, Kenya</h2>
                  </div>
                  <div className="bg-white/20 backdrop-blur-md px-3 py-1.5 rounded-full flex items-center gap-2 border border-white/20 shadow-sm">
                    <div className={`w-2 h-2 rounded-full ${isBusinessOpen ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`}></div>
                    <span className="text-white text-[10px] font-bold font-micro uppercase">{isBusinessOpen ? "OPEN" : "CLOSED"}</span>
                  </div>
                </div>

                {/* Open/Closed Toggle Switch Row with enhanced frosted glass styling */}
                <div className="mb-6 flex items-center justify-between bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 shadow-sm">
                  <div>
                    <h3 className="text-white font-title-medium font-bold">Shift status control</h3>
                    <p className="text-blue-100 text-[11px] font-medium mt-0.5 font-body-small">Toggle live online booking availability</p>
                  </div>
                  <button 
                    onClick={handleToggleOpenStatus}
                    className={`w-14 h-7 rounded-full p-1 relative transition-colors duration-300 focus:outline-none ${isBusinessOpen ? 'bg-emerald-500 shadow-inner' : 'bg-red-500 shadow-inner'}`}
                  >
                    <div className={`w-5 h-5 rounded-full bg-white shadow-md transform transition-transform duration-350 ease-out-back ${isBusinessOpen ? 'translate-x-7' : 'translate-x-0'}`} />
                  </button>
                </div>

                {/* 3-Column stats row in premium frosted cards */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center shadow-sm transition-transform hover:scale-[1.02]">
                    <p className="text-blue-100 text-[10px] uppercase font-bold tracking-wider mb-1 font-micro">Cars Today</p>
                    <p className="text-white text-lg font-black font-display-small">{totalCarsToday}</p>
                  </div>
                  <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center shadow-sm transition-transform hover:scale-[1.02]">
                    <p className="text-blue-100 text-[10px] uppercase font-bold tracking-wider mb-1 font-micro">Net revenue</p>
                    <p className="text-white text-lg font-black font-display-small">KSh {operatorPortion}</p>
                  </div>
                  <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3 border border-white/10 text-center shadow-sm transition-transform hover:scale-[1.02]">
                    <p className="text-blue-100 text-[10px] uppercase font-bold tracking-wider mb-1 font-micro">Avg Time</p>
                    <p className="text-white text-lg font-black font-display-small">24m</p>
                  </div>
                </div>

                {/* SaaS Subscription tier tracker */}
                <div 
                  onClick={() => setShowSubscriptionModal(true)}
                  className="mt-4 bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex items-center justify-between cursor-pointer transition-all active:scale-[0.99]"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-sm">⚡</span>
                    <div className="text-left">
                      <div className="flex items-center gap-1.5">
                        <span className="text-amber-300 text-[9px] font-black uppercase tracking-wider font-micro">SaaS Subscription Tier</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      </div>
                      <p className="text-white text-xs font-bold mt-0.5">
                        Active Plan: {operatorPlan === 'Pro' ? 'Pro Plan (KSh 2,999/mo, Recommended)' : operatorPlan === 'Growth' ? 'Growth Plan (KSh 1,499/mo, 10% Cut)' : 'Starter Plan (KSh 0/mo, 20% Cut)'}
                      </p>
                    </div>
                  </div>
                  <span className="text-[9px] text-amber-300 font-bold bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-500/20 uppercase tracking-wider font-micro">
                    Details →
                  </span>
                </div>
                
                {/* Manual testing action line with pulsing light indicators */}
                <button
                  type="button"
                  onClick={() => {
                    if (incomingBooking) {
                      showToast("Approval already pending for active inline request!", "info");
                      return;
                    }
                    const names = ["Karanja Kariuki", "Rehema Mwenda", "Amina Yusuf", "Faraji Mwangi", "Zuwena Juma", "Njuguna Njoroge", "George Odhiambo"];
                    const plates = ["KCD 119H", "KCY 992P", "KBZ 553T", "KDD 980J", "KCE 412F", "KCA 777Y", "KDL 504L"];
                    const randomName = names[Math.floor(Math.random() * names.length)];
                    const randomPlate = plates[Math.floor(Math.random() * plates.length)];
                    const randomService = services[Math.floor(Math.random() * services.length)] || services[0];
                    
                    setIncomingBooking({
                      id: 'REQ_' + Math.random().toString(36).substring(2, 6).toUpperCase(),
                      user_name: randomName,
                      initials: randomName.split(' ').map(n => n[0]).join(''),
                      plate: randomPlate,
                      time: 'Immediate',
                      amount: randomService.price,
                      plan: randomService.name,
                      duration: randomService.duration,
                      status: 'Confirmed'
                    });
                    showToast("🔔 Manual online booking simulator triggered!", "success");
                  }}
                  className="mt-4 w-full bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-2.5 border border-white/10 text-center shadow-sm text-xs font-title-medium text-white flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer"
                >
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-300"></span>
                  </span>
                  Test Simulation: Push Live Customer Booking Request
                </button>
              </div>

              {/* Main Content Pane */}
              <div className="px-4 py-5 flex flex-col gap-5">
                
                {/* 1. UP NEXT CRITICAL CARD */}
                {bookings.some((b) => b.status === 'Confirmed') && (
                  <div>
                    <p className="font-caption text-slate-400 mb-2">⚡ Up Next In Queue</p>
                    {bookings.filter((b) => b.status === 'Confirmed').slice(0, 1).map((booking) => (
                      <div key={booking.id} className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-16 h-16 bg-blue-50 bg-opacity-40 rounded-full blur-xl pointer-events-none"></div>
                        <div className="flex items-start gap-3">
                          <div className="w-11 h-11 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-title-medium">
                            {booking.initials}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <h3 className="font-title-medium text-slate-800">{booking.user_name}</h3>
                              <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 font-caption text-[9px] uppercase tracking-wider font-bold">
                                {booking.plan}
                              </span>
                            </div>
                            <span className="font-title-medium text-blue-600 tracking-wider block mt-0.5">{booking.plate}</span>
                            
                            <div className="flex items-center gap-4 mt-3">
                              <div className="flex items-center gap-1 text-slate-500">
                                <Clock size={13} />
                                <span className="font-body-small-bold">{booking.time}</span>
                              </div>
                              <span className="font-body-small-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md">
                                {booking.amount} KES
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Blue Action Button */}
                        <div className="mt-4 pt-3 border-t border-slate-50">
                          <button 
                            onClick={() => handleCheckInBtnClick(booking)}
                            className="w-full bg-blue-600 text-white font-title-medium text-center py-2.5 rounded-xl hover:bg-blue-700 active:scale-[0.98] transition-all cursor-pointer shadow-sm shadow-blue-200"
                          >
                            Check In Patient Arrival
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 2. LIVE ACTIVE PROGRESS PREVIEW CONTAINER */}
                {activeWashBooking && (
                  <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 shadow-sm flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center text-white font-title-medium animate-pulse">
                        🫧
                      </div>
                      <div>
                        <p className="font-caption text-blue-500">Current Washing Progress</p>
                        <p className="font-title-medium text-slate-800">{activeWashBooking.user_name} ({activeWashBooking.plate})</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setActiveTab('Wash')}
                      className="bg-white border border-blue-200 text-blue-600 px-3 py-1.5 rounded-xl font-body-small-bold hover:bg-blue-100"
                    >
                      View timer
                    </button>
                  </div>
                )}

                {/* 3. TODAY'S QUEUE */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-caption text-slate-400">📋 Today's Booking Queue</p>
                    <span className="font-micro font-semibold text-slate-500">{bookings.length} active entries</span>
                  </div>

                  <div className="flex flex-col gap-2.5">
                    {bookings.map((booking) => {
                      const isWashing = booking.status === 'In Progress';
                      const isOverdue = booking.status === 'Overdue';
                      const isConfirmed = booking.status === 'Confirmed';
                      
                      const badgeBg = isWashing 
                        ? 'bg-amber-100 text-amber-600 border-amber-200/50' 
                        : isOverdue 
                        ? 'bg-red-50 text-red-600 border-red-100' 
                        : 'bg-blue-50 text-blue-600 border-blue-100';

                      return (
                        <div 
                          key={booking.id}
                          onClick={() => handleCheckInBtnClick(booking)}
                          className="bg-white border border-slate-100 rounded-2xl p-3.5 shadow-sm flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-3">
                            <div className={`w-9 h-9 rounded-full flex items-center justify-center font-body-medium-bold ${isWashing ? 'bg-amber-100 text-amber-700' : 'bg-blue-50 text-blue-700'}`}>
                              {booking.initials}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="font-title-medium text-slate-800">{booking.user_name}</h4>
                                <span className={`px-2 py-0.5 rounded-full border text-[9px] font-caption tracking-normal ${badgeBg}`}>
                                  {booking.status}
                                </span>
                              </div>
                              <div className="flex items-center gap-3 mt-1.5">
                                <span className="font-title-medium text-blue-600 tracking-wider text-[13px]">{booking.plate}</span>
                                <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                                <div className="flex items-center gap-0.5 text-slate-500 font-body-small">
                                  <Clock size={11} />
                                  <span>{booking.time}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          <ChevronRight size={16} className="text-slate-400" />
                        </div>
                      );
                    })}
                  </div>
                </div>

              </div>
            </div>
          )}


          {/* SCREEN: QR SCAN */}
          {activeTab === 'Scan' && (
            <div className="flex flex-col flex-1 px-4 py-5 gap-5">
              <div className="text-center">
                <h1 className="font-display-small text-slate-800">QR Code Verification</h1>
                <p className="font-body-small text-slate-500 mt-1">Authorized Coastline scanning console terminal</p>
              </div>

              {/* Slate-800 Simulated Camera Screen */}
              <div className="w-full aspect-square bg-slate-800 rounded-[2rem] border-4 border-slate-900 shadow-inner relative flex flex-col items-center justify-center p-8 overflow-hidden">
                
                {/* Neon Corner Brackets */}
                <div className="absolute top-6 left-6 w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-lg"></div>
                <div className="absolute top-6 right-6 w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-lg"></div>
                <div className="absolute bottom-6 left-6 w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-lg"></div>
                <div className="absolute bottom-6 right-6 w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-lg"></div>

                {/* SVG QR Code graphic pattern */}
                <svg className="w-48 h-48 text-white max-w-full opacity-85" viewBox="0 0 100 100" fill="currentColor">
                  {/* Outer square frame top left */}
                  <path d="M5 5h20v20H5V5zm4 4v12h12V9H9z"/>
                  <rect x="13" y="13" width="4" height="4" />
                  
                  {/* Outer square frame top right */}
                  <path d="M75 5h20v20H75V5zm4 4v12h12V9H79z"/>
                  <rect x="83" y="13" width="4" height="4" />

                  {/* Outer square frame bottom left */}
                  <path d="M5 75h20v20H5V75zm4 4v12h12V9H9z" transform="translate(0, 150) scale(1, -1)" />
                  <rect x="13" y="83" width="4" height="4" />

                  {/* Mock QR dots and structures */}
                  <rect x="35" y="5" width="4" height="8" />
                  <rect x="45" y="5" width="8" height="4" />
                  <rect x="60" y="5" width="10" height="4" />
                  <rect x="45" y="15" width="4" height="4" />
                  <rect x="55" y="12" width="12" height="4" />
                  
                  <rect x="35" y="30" width="8" height="8" />
                  <rect x="5" y="35" width="15" height="4" />
                  <rect x="10" y="45" width="4" height="15" />
                  <rect x="25" y="45" width="20" height="4" />
                  
                  <rect x="50" y="35" width="4" height="20" />
                  <rect x="60" y="40" width="12" height="4" />
                  <rect x="78" y="32" width="14" height="14" />
                  <rect x="82" y="36" width="6" height="6" fill="#2563EB" />

                  <rect x="30" y="65" width="8" height="4" />
                  <rect x="45" y="60" width="4" height="15" />
                  <rect x="55" y="65" width="16" height="4" />
                  <rect x="35" y="75" width="4" height="20" />
                  <rect x="45" y="85" width="15" height="4" />
                  <rect x="65" y="80" width="20" height="4" />
                  <rect x="80" y="65" width="4" height="25" />
                  <rect x="90" y="55" width="5" height="30" />
                  <rect x="70" y="50" width="12" height="4" />
                </svg>

                {/* Animated blue scan laser line bar across middle */}
                <motion.div 
                  animate={{ y: [-90, 90, -90] }}
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className="absolute left-6 right-6 h-1 bg-gradient-to-r from-transparent via-blue-400 to-transparent shadow-[0_0_12px_rgba(59,130,246,0.8)]"
                ></motion.div>
                
                {/* QR scanning focus prompt label */}
                <span className="absolute bottom-4 font-caption text-blue-400 font-semibold uppercase tracking-widest text-[9px] bg-slate-900/80 px-3 py-1 rounded-full">
                  Align code within bracket range
                </span>
              </div>

              {/* Simulated QR Trigger Button and Quick Scan Options */}
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => handleSimulateQRScan()}
                  className="w-full bg-blue-600 text-white font-title-medium text-center py-3.5 rounded-2xl hover:bg-blue-700 shadow-md shadow-blue-200 active:scale-[0.98] transition-all cursor-pointer"
                >
                  📸 Simulate Automatic QR Code Scan
                </button>
                
                {/* Scan Simulator Picker Shortcuts */}
                <div className="flex items-center justify-between mt-1 bg-white border border-slate-100 rounded-xl p-2.5">
                  <span className="font-body-small text-slate-500">Scan customer QR codes:</span>
                  <div className="flex gap-1.5">
                    <button onClick={() => handleSimulateQRScan('B4')} className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-caption text-[10px] hover:bg-slate-200">
                      Mary
                    </button>
                    <button onClick={() => handleSimulateQRScan('B5')} className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-caption text-[10px] hover:bg-slate-200">
                      Johnstone
                    </button>
                  </div>
                </div>
              </div>

              {/* Or search by plate design divider */}
              <div className="flex items-center gap-3 my-1">
                <div className="flex-1 h-px bg-slate-100"></div>
                <span className="font-caption text-slate-400 font-semibold uppercase text-[10px]">or search manually</span>
                <div className="flex-1 h-px bg-slate-100"></div>
              </div>

              {/* Number Plate Search form input block */}
              <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                <label className="font-caption text-slate-400">Kenya Number Plate</label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400">
                    <Search size={18} />
                  </span>
                  <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="e.g. KDD 884X"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSearchPlate();
                    }}
                    className="w-full bg-slate-50 border border-slate-100 rounded-xl py-3 pl-11 pr-4 font-body-large text-slate-800 placeholder-slate-400 uppercase tracking-widest focus:outline-none focus:border-blue-400"
                  />
                </div>
                <button 
                  onClick={handleSearchPlate}
                  className="w-full bg-slate-900 text-white font-title-medium text-center py-3 rounded-xl hover:bg-slate-800 active:scale-[0.98] transition-all cursor-pointer"
                >
                  Verify Number Plate Registry
                </button>
              </div>

              {/* Recent Scan History */}
              {recentScans.length > 0 && (
                <div>
                  <p className="font-caption text-slate-400 mb-2"> Recently Scanned Passes</p>
                  <div className="flex flex-col gap-2">
                    {recentScans.map((b) => (
                      <div 
                        key={b.id} 
                        onClick={() => setVerifiedBooking(b)}
                        className="bg-white border border-slate-100 rounded-xl p-3 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3.5">
                          <span className="text-lg">✅</span>
                          <div>
                            <p className="font-title-small text-slate-800">{b.user_name}</p>
                            <p className="font-caption text-blue-600 tracking-wider text-[12px]">{b.plate} · {b.plan}</p>
                          </div>
                        </div>
                        <span className="font-caption text-[10px] text-slate-400">View details</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}


          {/* SCREEN: WASH IN PROGRESS */}
          {activeTab === 'Wash' && (
            <div className="flex flex-col flex-1 px-4 py-5 gap-5">
              <div className="text-center">
                <h1 className="font-display-small text-slate-800">Active Wash Station</h1>
                <p className="font-body-small text-slate-500 mt-1">Real-time status, progress tracking, and supervisor check-off</p>
              </div>

              {/* Ensure an active wash belongs to our viewport */}
              {!activeWashBooking ? (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-6 bg-white border border-slate-100 rounded-3xl shadow-sm gap-4 my-8">
                  <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center font-display-medium text-3xl">
                    🚿
                  </div>
                  <div>
                    <h3 className="font-title-large text-slate-800">No Active Wash In Progress</h3>
                    <p className="font-body-small text-slate-500 mt-2 max-w-[280px] mx-auto">
                      All bays are currently clear or waiting. Check in an arrival from the queue to start a live progress timer.
                    </p>
                  </div>
                  
                  {/* Shortcut to assign or check in */}
                  <div className="w-full flex flex-col gap-2 mt-4">
                    <button 
                      onClick={() => setActiveTab('Home')}
                      className="w-full bg-blue-600 text-white font-title-medium text-center py-3 rounded-xl shadow-md shadow-blue-100 block"
                    >
                      Browse Today's Queue
                    </button>
                    
                    {/* fallback quick resume mock in progress */}
                    {bookings.some(b => b.status === "In Progress") && (
                      <button 
                        onClick={() => {
                          const ip = bookings.find(b => b.status === "In Progress");
                          if (ip) {
                            setActiveBookingId(ip.id);
                            showToast(`Resumed monitoring for ${ip.user_name}`, "info");
                          }
                        }}
                        className="w-full bg-slate-900 text-white font-title-medium text-center py-3 rounded-xl shadow-md"
                      >
                        Monitor Existing Wash
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-5">
                  
                  {/* Select other active washes if multiple exist */}
                  {inProgressList.length > 1 && (
                    <div className="flex items-center gap-1.5 overflow-x-auto hide-scrollbar pb-1">
                      {inProgressList.map((b) => (
                        <button
                          key={b.id}
                          onClick={() => setActiveBookingId(b.id)}
                          className={`px-3 py-2 rounded-xl font-body-small-bold whitespace-nowrap border flex-shrink-0 ${
                            b.id === activeBookingId 
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                              : 'bg-white text-slate-700 border-slate-100'
                          }`}
                        >
                          🚗 {b.plate} ({b.user_name.split(' ')[0]})
                        </button>
                      ))}
                    </div>
                  )}

                  {/* SVG circular progress ring on white card background */}
                  <div className="bg-white border border-slate-100 rounded-3xl p-6 shadow-sm flex flex-col items-center justify-center">
                    
                    {/* SVG circular progress indicator code */}
                    <div className="relative w-48 h-48 flex items-center justify-center">
                      
                      {/* Compute actual step-based percentage */}
                      {(() => {
                        const completedSteps = stepsProgress[activeWashBooking.id] || [];
                        const pct = Math.round((completedSteps.length / WASH_STEPS.length) * 100);
                        const radius = 80;
                        const circumference = 2 * Math.PI * radius;
                        const strokeDashoffset = circumference - (pct / 100) * circumference;

                        return (
                          <>
                            <svg className="w-full h-full transform -rotate-90">
                              {/* Background track circle */}
                              <circle 
                                cx="96" 
                                cy="96" 
                                r={radius} 
                                className="stroke-slate-100 fill-none" 
                                strokeWidth="12"
                              />
                              {/* Active progress track circle */}
                              <circle 
                                cx="96" 
                                cy="96" 
                                r={radius} 
                                className="stroke-blue-600 fill-none transition-all duration-500 ease-out" 
                                strokeWidth="12"
                                strokeDasharray={circumference}
                                strokeDashoffset={strokeDashoffset}
                                strokeLinecap="round"
                              />
                            </svg>
                            
                            {/* Centered raw timer detail text info */}
                            <div className="absolute flex flex-col items-center justify-center text-center">
                              <h2 className="font-display-medium text-slate-800 font-bold leading-none">
                                {formatTimer(timers[activeWashBooking.id] || 0)}
                              </h2>
                              <p className="font-micro text-blue-600 font-bold mt-2.5 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-100">
                                {pct}% Done
                              </p>
                            </div>
                          </>
                        );
                      })()}
                    </div>

                    <div className="text-center mt-4">
                      <p className="font-caption text-slate-400 uppercase tracking-widest text-[9px]">Vehicle in Bay 2</p>
                      <h3 className="font-title-large text-slate-800 mt-1">{activeWashBooking.user_name}</h3>
                      <p className="font-title-medium text-blue-600 tracking-widest mt-0.5">{activeWashBooking.plate}</p>
                    </div>
                  </div>

                  {/* Operator/Washer profile card with dynamic state & quick reassignment dropdown */}
                  {(() => {
                    const assignedWasher = washers.find((w) => w.id === activeWashBooking.assignedWasherId) || washers[0];
                    return (
                      <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                        <div className="flex items-center gap-3.5">
                          <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white text-base font-black shadow-sm ${assignedWasher?.avatarColor || 'bg-blue-600 text-white'}`}>
                            {assignedWasher?.name.split(' ').map(n=>n[0]).join('') || '👷'}
                          </div>
                          <div className="flex-1">
                            <p className="font-caption text-slate-400 text-[9px] uppercase tracking-wider">Assigned Lead Washer</p>
                            <h4 className="font-title-medium text-slate-800 mt-0.5">{assignedWasher?.name || 'Unassigned Crew'}</h4>
                            <p className="font-body-small text-slate-400 mt-0.5">{assignedWasher?.role || 'Crew Member'}</p>
                          </div>
                        </div>
                        
                        {/* Quick Washer Rerouting System */}
                        <div className="border-t border-slate-50 pt-2.5">
                          <p className="font-caption text-slate-400 text-[9px] uppercase tracking-wider mb-2">Reassign Lead Washer Duty</p>
                          <div className="flex gap-1.5 overflow-x-auto hide-scrollbar pb-1">
                            {washers.map((w) => {
                              const isAssigned = w.id === activeWashBooking.assignedWasherId;
                              return (
                                <button
                                  key={w.id}
                                  onClick={() => {
                                    setBookings((prev) =>
                                      prev.map((b) =>
                                        b.id === activeWashBooking.id ? { ...b, assignedWasherId: w.id } : b
                                      )
                                    );
                                    showToast(`Reassigned active washing duty to ${w.name}!`, "success");
                                  }}
                                  className={`px-3 py-1.5 rounded-xl text-[11px] font-title-medium flex items-center gap-1.5 border transition-all flex-shrink-0 cursor-pointer ${
                                    isAssigned 
                                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm font-bold' 
                                      : 'bg-slate-50 text-slate-600 border-slate-200/40 hover:bg-slate-100 font-medium'
                                  }`}
                                >
                                  <span className={`w-1.5 h-1.5 rounded-full ${isAssigned ? 'bg-white' : 'bg-emerald-500'}`}></span>
                                  {w.name.split(' ')[0]}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    );
                  })()}

                  {/* 2x2 grid of booking detail chips (slate-50 background) */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100/50">
                      <span className="font-micro text-slate-400">Wash Plan</span>
                      <p className="font-title-small text-slate-800 mt-1">✨ {activeWashBooking.plan}</p>
                    </div>
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100/50">
                      <span className="font-micro text-slate-400">Estimated Duration</span>
                      <p className="font-title-small text-slate-800 mt-1">⏱ {activeWashBooking.duration} Mins</p>
                    </div>
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100/50">
                      <span className="font-micro text-slate-400">Total Price Value</span>
                      <p className="font-title-small text-slate-800 mt-1">💵 {activeWashBooking.amount} KES</p>
                    </div>
                    <div className="bg-slate-50 rounded-xl p-3 border border-slate-100/50">
                      <span className="font-micro text-slate-400">Assigned Bay</span>
                      <p className="font-title-small text-slate-800 mt-1">🌊 Standard Bay 2</p>
                    </div>
                  </div>

                  {/* Wash steps checklist */}
                  <div>
                    <h3 className="font-caption text-slate-400 mb-2">🚿 Active Service Quality Checklist Check-off</h3>
                    <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                      {WASH_STEPS.map((step, idx) => {
                        const isCompleted = (stepsProgress[activeWashBooking.id] || []).includes(step.id);
                        return (
                          <div 
                            key={step.id}
                            onClick={() => toggleStepCompleted(activeWashBooking.id, step.id)}
                            className="flex items-center gap-3 select-none cursor-pointer group"
                          >
                            <div className={`w-5.5 h-5.5 rounded-full flex items-center justify-center transition-all ${
                              isCompleted 
                                ? 'bg-blue-600 text-white border-blue-600 scale-105' 
                                : 'border-2 border-slate-200 text-transparent group-hover:border-blue-400'
                            }`}>
                              <Check size={11} strokeWidth={3} />
                            </div>
                            <span className={`font-body-medium flex-1 text-slate-700 transition-all ${
                              isCompleted 
                                ? 'line-through text-slate-400 italic' 
                                : 'group-hover:text-slate-900'
                            }`}>
                              {idx + 1}. {step.title}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Full width Complete Wash blue button that turns emerald when tapped */}
                  {(() => {
                    const completed = (stepsProgress[activeWashBooking.id] || []).length === WASH_STEPS.length;
                    return (
                      <button 
                        onClick={() => handleCompleteWash(activeWashBooking)}
                        className={`w-full py-4 rounded-xl font-title-medium text-center transition-all duration-300 shadow-md ${
                          completed 
                            ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-100 scale-102 hover:scale-105' 
                            : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100'
                        }`}
                      >
                        {completed ? "✓ Complete & Release Vehicle (100% Verified)" : "Skip & Force Complete Wash"}
                      </button>
                    );
                  })()}

                </div>
              )}

            </div>
          )}


          {/* SCREEN: EARNINGS SCREEN */}
          {activeTab === 'Earnings' && (
            <div className="flex flex-col flex-1 px-4 py-5 gap-5">
              <div className="text-center">
                <h1 className="font-display-small text-slate-800">Financial Reports</h1>
                <p className="font-body-small text-slate-500 mt-1">Earnings ledger, analytical payouts & trends</p>
              </div>

              {/* White card with recharts BarChart */}
              <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col gap-4">
                
                {/* Header elements with toggle pills */}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-caption text-slate-400">Selected Ledger</span>
                    <h3 className="font-title-medium text-slate-800 mt-0.5">Coastline Wash Revenue</h3>
                  </div>
                  
                  {/* Toggle pills */}
                  <div className="bg-slate-50 border border-slate-100 rounded-xl p-1 flex gap-1">
                    <button 
                      onClick={() => setEarningsPeriod('Week')}
                      className={`px-3 py-1 rounded-lg font-caption text-[10px] uppercase font-bold transition-all ${
                        earningsPeriod === 'Week' 
                          ? 'bg-blue-600 text-white shadow-sm' 
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Week
                    </button>
                    <button 
                      onClick={() => setEarningsPeriod('Month')}
                      className={`px-3 py-1 rounded-lg font-caption text-[10px] uppercase font-bold transition-all ${
                        earningsPeriod === 'Month' 
                          ? 'bg-blue-600 text-white shadow-sm' 
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                    >
                      Month
                    </button>
                  </div>
                </div>

                {/* Total amount bold text */}
                <div>
                  <h2 className="font-display-medium text-slate-900 tracking-tight">KSh {(earningsPeriod === 'Week' ? weeklyRevenue : monthlyRevenue).toLocaleString()}</h2>
                  <p className="font-body-small text-slate-500 mt-0.5">Estimated total operator payout (after {Math.round(currentCommissionRate * 100)}% dynamic commission)</p>
                </div>

                {/* Recharts BarChart container with custom styling */}
                <div className="w-full h-44 mt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={currentChartData} margin={{ top: 10, right: 10, left: -25, bottom: 5 }}>
                      <XAxis 
                        dataKey="day" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94A3B8', fontSize: 10 }} 
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#94A3B8', fontSize: 10 }}
                      />
                      <Tooltip 
                        cursor={{ fill: 'rgba(59, 130, 246, 0.05)' }} 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-slate-900 text-white px-3 py-1.5 rounded-lg shadow-md border border-slate-800">
                                <p className="font-body-small-bold">{payload[0].value} KSh</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar 
                        dataKey="ksh" 
                        radius={[6, 6, 0, 0]}
                        maxBarSize={28}
                      >
                        {currentChartData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill="#2563EB" 
                            opacity={0.88}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* 3-Column summary cards (Today / This Week / This Month) */}
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm text-center">
                  <span className="font-micro text-slate-400">Today</span>
                  <p className="font-title-medium text-slate-800 mt-1">{operatorPortion} KSh</p>
                  <span className="font-micro text-emerald-600 block mt-1">▲ +12%</span>
                </div>
                <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm text-center">
                  <span className="font-micro text-slate-400">This Week</span>
                  <p className="font-title-medium text-slate-800 mt-1">{Math.round(weeklyRevenue).toLocaleString()} KSh</p>
                  <span className="font-micro text-emerald-600 block mt-1">▲ +8%</span>
                </div>
                <div className="bg-white border border-slate-100 rounded-2xl p-3 shadow-sm text-center">
                  <span className="font-micro text-slate-400">This Month</span>
                  <p className="font-title-medium text-slate-800 mt-1">{Math.round(monthlyRevenue).toLocaleString()} KSh</p>
                  <span className="font-micro text-red-500 block mt-1">▼ -3%</span>
                </div>
              </div>

              {/* Educational info widget explaining the billing structure */}
              <div className="bg-gradient-to-tr from-slate-900 to-slate-850 text-white rounded-3xl p-4.5 border border-slate-800 shadow-lg flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-amber-400 text-sm">💡</span>
                    <h4 className="font-caption text-amber-400 font-extrabold text-[10px] tracking-wider uppercase">How Operator Billing Works</h4>
                  </div>
                  <div className="bg-blue-500/25 text-blue-300 border border-blue-400/20 px-2.5 py-0.5 rounded-full text-[9px] font-bold font-micro">
                    SAAS TIERS ACTIVE
                  </div>
                </div>
                
                <p className="font-body-small text-slate-350 text-[11px] leading-relaxed">
                  SplashPass operates on a multi-tier SaaS pricing model tailored to your business volume:
                </p>

                <div className="grid grid-cols-3 gap-2 mt-0.5">
                  <div className={`border p-2.5 rounded-xl text-left transition-all ${operatorPlan === 'Starter' ? 'bg-blue-600/25 border-blue-500 text-white' : 'bg-white/5 border-white/5'}`}>
                    <div className="flex items-center gap-1">
                      <span className="text-[10px] font-bold text-slate-300">Starter</span>
                    </div>
                    <p className="text-[11px] font-black text-rose-300 mt-1">20% Cut</p>
                    <p className="text-[8px] text-slate-400 mt-0.5 leading-tight">KES 0/mo subscription fee.</p>
                  </div>

                  <div className={`border p-2.5 rounded-xl text-left transition-all ${operatorPlan === 'Growth' ? 'bg-blue-600/25 border-blue-500 text-white' : 'bg-white/5 border-white/5'}`}>
                    <div className="flex items-center gap-1 font-sans">
                      <span className="text-[10px] font-bold text-slate-300">Growth</span>
                    </div>
                    <p className="text-[11px] font-black text-amber-300 mt-1">10% Cut</p>
                    <p className="text-[8px] text-slate-400 mt-0.5 leading-tight">+ KES 1,499/mo subscription.</p>
                  </div>

                  <div className={`border p-2.5 rounded-xl text-left transition-all ${operatorPlan === 'Pro' ? 'bg-blue-600/25 border-blue-500 text-white' : 'bg-white/5 border-white/5'}`}>
                    <div className="flex items-center gap-1 font-sans">
                      <span className="text-[10px] font-bold text-slate-300">Pro ⭐</span>
                    </div>
                    <p className="text-[11px] font-black text-emerald-300 mt-1">0% Cut</p>
                    <p className="text-[8px] text-slate-400 mt-0.5 leading-tight">KES 2,999/mo (Recommended).</p>
                  </div>
                </div>

                <div className="border-t border-white/5 pt-2.5 flex items-center justify-between mt-1 font-sans">
                  <span className="text-[10px] text-slate-400 font-semibold font-micro">Current Plan: <span className="text-white font-bold">{operatorPlan}</span></span>
                  <button 
                    onClick={() => setShowSubscriptionModal(true)}
                    className="text-xs text-blue-400 hover:text-blue-300 font-bold font-title-medium flex items-center gap-1 cursor-pointer bg-transparent border-0 outline-none"
                  >
                    Adjust SaaS Tiers →
                  </button>
                </div>
              </div>

              {/* Recent Transaction Log lists */}
              <div>
                <p className="font-caption text-slate-400 mb-2.5">Recent Settled Transactions</p>
                <div className="flex flex-col gap-2">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="bg-white border border-slate-100 rounded-2xl p-3.5 shadow-sm flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 font-body-medium-bold">
                          {tx.user_name.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <h4 className="font-title-medium text-slate-800">{tx.user_name}</h4>
                          <span className="font-body-small text-slate-500 block mt-0.5">{tx.type} · {tx.time}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-title-medium text-emerald-600 font-bold">+{tx.amount} KES</span>
                        <span className="font-micro text-slate-400 block mt-0.5">Settled</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}


          {/* SCREEN: MORE SCREEN */}
          {activeTab === 'More' && (
            <div className="flex flex-col flex-1 px-4 py-5 gap-5">
              
              {/* Profile banner block with blue-600 background */}
              <div className="bg-gradient-to-tr from-blue-700 to-blue-600 text-white rounded-[2rem] p-5.5 shadow-md relative overflow-hidden flex items-center gap-4">
                <div className="absolute top-0 left-0 w-24 h-24 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>
                <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/25 flex items-center justify-center text-white font-display-small font-bold">
                  CC
                </div>
                <div>
                  <h2 className="font-title-large text-white tracking-tight">Coastline Operator</h2>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span className="font-caption text-blue-100 text-[10px] font-bold uppercase tracking-widest">Active session online</span>
                  </div>
                </div>
              </div>

              {/* SaaS Subscription Status Widget on More tab */}
              <div 
                onClick={() => setShowSubscriptionModal(true)}
                className="bg-white border border-slate-100 rounded-[2rem] p-4.5 shadow-sm relative overflow-hidden cursor-pointer hover:bg-slate-50 transition-colors flex flex-col gap-3"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/50 rounded-full blur-xl pointer-events-none"></div>
                
                <div className="flex items-center justify-between font-sans">
                  <div className="flex items-center gap-2">
                    <span className="text-blue-500 font-bold text-base">💎</span>
                    <h4 className="font-caption text-indigo-950 font-black text-[11px] tracking-wider uppercase">SaaS Subscription</h4>
                  </div>
                  <span className="text-[10px] text-blue-700 bg-blue-50 border border-blue-200 font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider font-micro">
                    {operatorPlan} Active
                  </span>
                </div>

                <div>
                  <h3 className="font-title-large text-slate-800 font-extrabold text-sm">
                    {operatorPlan === 'Pro' 
                      ? 'Pro Plan (KSh 2,999/mo, 0% Comm.)' 
                      : operatorPlan === 'Growth' 
                        ? 'Growth Plan (KSh 1,499/mo, 10% Comm.)' 
                        : 'Starter Plan (KSh 0/mo, 20% Comm.)'}
                  </h3>
                  <p className="font-body-small text-[11px] text-slate-500 mt-1 leading-relaxed">
                    {operatorPlan === 'Pro' 
                      ? "Recommended for high-volume depots! You keep 100% of driver cashflows. Subscription renews automatically on next billing cycle." 
                      : operatorPlan === 'Growth' 
                        ? "Perfect middle tier for growing stations. Low monthly fee coupled with low transaction platform splits." 
                        : "Pay-as-you-go basic plan with standard 20% processing cut on routing customer bookings. Upgrade anytime to save!"}
                  </p>
                </div>

                {/* Progress bar representing status health */}
                <div className="mt-1 font-sans">
                  <div className="flex justify-between items-center text-[9px] font-bold text-slate-400 font-micro mb-1">
                    <span>SaaS SYSTEM HEALTH: EXCELLENT</span>
                    <span className="text-emerald-500 font-black">ONLINE</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="w-[100%] h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"></div>
                  </div>
                </div>

                <div className="border-t border-slate-50 pt-3 flex items-center justify-between font-sans">
                  <span className="text-[9px] font-bold text-slate-400 font-micro uppercase">Billing Cycle: Monthly Renewal</span>
                  <span className="text-[11px] font-bold text-blue-600 font-title-medium flex items-center gap-0.5">
                    Adjust Level →
                  </span>
                </div>
              </div>

              {/* Grouped section 1: Business Operations */}
              <div>
                <p className="font-caption text-slate-400 mb-2">🏪 Station Operations</p>
                <div className="bg-white border border-slate-100 rounded-2xl p-1 shadow-sm flex flex-col">
                  {[
                    { emoji: "🕒", label: "Station Work Hours", subtitle: "08:00 AM - 08:00 PM" },
                    { emoji: "⚡", label: "Configure Service List", subtitle: "Manage plans, durations & pricing list" },
                    { emoji: "👷", label: "Monitor staff wash on duty", subtitle: "Active staff rosters & commissions" },
                  ].map((row, idx) => (
                    <div 
                      key={idx} 
                      onClick={() => {
                        if (idx === 0) {
                          handleToggleOpenStatus();
                        } else if (idx === 1) {
                          setShowServicesModal(true);
                        } else if (idx === 2) {
                          setShowWashersModal(true);
                        }
                      }}
                      className="p-3.5 flex items-center justify-between border-b last:border-0 border-slate-50 hover:bg-slate-50/50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{row.emoji}</span>
                        <div>
                          <p className="font-title-small text-slate-800">{row.label}</p>
                          <p className="font-body-small text-slate-400 mt-0.5">{row.subtitle}</p>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Grouped section 2: Reports */}
              <div>
                <p className="font-caption text-slate-400 mb-2">📊 Analytics & Reporting</p>
                <div className="bg-white border border-slate-100 rounded-2xl p-1 shadow-sm flex flex-col">
                  {[
                    { emoji: "📥", label: "Export PDF Invoice summaries", subtitle: "Download payout summaries" },
                    { emoji: "📈", label: "Performance statistics", subtitle: "Track peak wash hour analytics" },
                  ].map((row, idx) => (
                    <div 
                      key={idx} 
                      onClick={() => showToast(`Report trigger: Preparing ledger download...`, "success")}
                      className="p-3.5 flex items-center justify-between border-b last:border-0 border-slate-50 hover:bg-slate-50/50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{row.emoji}</span>
                        <div>
                          <p className="font-title-small text-slate-800">{row.label}</p>
                          <p className="font-body-small text-slate-400 mt-0.5">{row.subtitle}</p>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Grouped section 3: Account */}
              <div>
                <p className="font-caption text-slate-400 mb-2">👤 Account Settings</p>
                <div className="bg-white border border-slate-100 rounded-2xl p-1 shadow-sm flex flex-col">
                  {[
                    { emoji: "⚙️", label: "Profile and Payout Settings", subtitle: "Abdi Omar · Mombasa operator" },
                    { emoji: "🔒", label: "Security & Passcodes", subtitle: "Alter kiosk access credentials" },
                  ].map((row, idx) => (
                    <div 
                      key={idx} 
                      onClick={() => showToast(`Setting saved`, "info")}
                      className="p-3.5 flex items-center justify-between border-b last:border-0 border-slate-50 hover:bg-slate-50/50 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{row.emoji}</span>
                        <div>
                          <p className="font-title-small text-slate-800">{row.label}</p>
                          <p className="font-body-small text-slate-400 mt-0.5">{row.subtitle}</p>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-slate-400" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Grouped section 4: LOG OUT WITH NO CHEVRON AND RED TEXT */}
              <div className="bg-white border border-slate-100 rounded-2xl p-1 shadow-sm mt-2">
                <div 
                  onClick={() => {
                    if (confirm("Disconnect session?")) {
                      setActiveTab('Home');
                      showToast("Session disconnected.", "info");
                    }
                  }}
                  className="p-4 flex items-center gap-3 cursor-pointer hover:bg-red-50/40"
                >
                  <span className="text-red-500 text-xl">🚪</span>
                  <div className="flex-1">
                    <p className="font-title-small text-red-600 font-bold">Log Out of Console Connection</p>
                    <p className="font-body-small text-red-400 mt-0.5">Disconnect device session on this station</p>
                  </div>
                </div>
              </div>

              {/* Version numbering branding */}
              <p className="font-caption text-slate-400 font-semibold text-center text-[10px] tracking-wide my-3">
                Coastline Operator v2.4.1 · Mombasa
              </p>

            </div>
          )}

        </div>

        {/* BOTTOM NAVIGATION TAB BAR */}
        <div className="absolute bottom-0 left-0 right-0 h-18 px-3 bg-white/95 backdrop-blur-md border-t border-slate-100 flex items-center justify-around pb-2 z-40">
          {[
            { id: 'Home', icon: <HomeIcon size={20} />, label: 'Home' },
            { id: 'Scan', icon: <QrCode size={20} />, label: 'Scan' },
            { id: 'Wash', icon: <Droplet size={20} />, label: 'Wash' },
            { id: 'Earnings', icon: <TrendingUp size={20} />, label: 'Earnings' },
            { id: 'More', icon: <MoreHorizontal size={20} />, label: 'More' }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                }}
                className="flex flex-col items-center justify-center flex-1 h-full gap-1 text-center transition-all bg-transparent border-0 outline-none cursor-pointer"
              >
                <div className={`transition-transform duration-200 ${isActive ? 'text-blue-600 scale-110 drop-shadow-[0_2px_4px_rgba(37,99,235,0.15)]' : 'text-slate-400'}`}>
                  {tab.icon}
                </div>
                <span className={`font-micro transition-colors text-[9px] ${isActive ? 'text-blue-600 font-bold' : 'text-slate-400'}`}>
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* iOS Home Indicator notch line at absolute bottom */}
        <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-32 h-1 bg-slate-900 rounded-full z-50"></div>

        {/* BOTTOM SHEET VERIFIED MODAL OVERLAY: BACKDROP BLUR + BLACK/50 */}
        <AnimatePresence>
          {verifiedBooking && (
            <div className="absolute inset-0 z-50 flex flex-col justify-end">
              
              {/* Back Drop Black Blur click outside close */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setVerifiedBooking(null)}
                className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              />

              {/* Bottom Sheet Menu */}
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 220 }}
                className="relative bg-white rounded-t-[2.5rem] p-6 flex flex-col gap-5 shadow-2xl z-10 select-none pb-8 max-h-[85%] overflow-y-auto hide-scrollbar"
              >
                {/* Visual drag handle bar */}
                <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto -mt-2"></div>

                {/* Verified Green Icon Center */}
                <div className="flex flex-col items-center justify-center text-center gap-1.5">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-display-medium text-2xl shadow-sm">
                    <Check size={28} strokeWidth={3} />
                  </div>
                  <h2 className="font-caption text-emerald-500 font-extrabold tracking-widest text-[12px] mt-1">VERIFIED PASS</h2>
                  <p className="font-body-small text-slate-500">Authorized operator booking credentials matched</p>
                </div>

                {/* Customer card */}
                <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex items-center gap-4">
                  <div className="w-11 h-11 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-title-medium">
                    {verifiedBooking.initials}
                  </div>
                  <div>
                    <h3 className="font-title-large text-slate-800">{verifiedBooking.user_name}</h3>
                    <span className="font-title-medium text-blue-600 tracking-widest text-[13px] block mt-0.5">{verifiedBooking.plate}</span>
                  </div>
                </div>

                {/* Booking key-value details rows */}
                <div className="flex flex-col bg-white border border-slate-100 rounded-2xl p-4 divide-y divide-slate-50 shadow-sm">
                  <div className="flex items-center justify-between pb-3.5">
                    <span className="font-body-medium text-slate-500">Wash Type</span>
                    <span className="font-body-medium-bold text-slate-800">{verifiedBooking.plan}</span>
                  </div>
                  <div className="flex items-center justify-between py-3.5">
                    <span className="font-body-medium text-slate-500">Booking Time</span>
                    <div className="flex items-center gap-1 font-body-medium-bold text-slate-800">
                      <Clock size={14} className="text-slate-400" />
                      <span>{verifiedBooking.time}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-3.5">
                    <span className="font-body-medium text-slate-500">Estimated Duration</span>
                    <span className="font-body-medium-bold text-slate-800">⏱ {verifiedBooking.duration} mins</span>
                  </div>
                  <div className="flex items-center justify-between py-3.5">
                    <span className="font-body-medium text-slate-500">Total Price Due</span>
                    <span className="font-body-medium-bold text-slate-800 bg-blue-50 text-blue-700 px-2.5 py-0.5 rounded-lg">
                      {verifiedBooking.amount} KES
                    </span>
                  </div>
                  <div className="flex items-center justify-between py-3.5">
                    <span className="font-body-medium text-slate-500">Payment Badge</span>
                    <span className="px-2.5 py-0.5 rounded-lg text-[9px] font-caption tracking-normal bg-emerald-100 text-emerald-800">
                      PAID WEB CARD
                    </span>
                  </div>
                  <div className="flex items-center justify-between pt-3.5">
                    <span className="font-body-medium text-slate-500">Pre-Status Validation</span>
                    <span className="px-2.5 py-0.5 rounded-lg text-[9px] font-caption tracking-normal bg-blue-50 text-blue-700">
                      READY TO START
                    </span>
                  </div>
                </div>

                {/* Lead Washer Assignment Grid */}
                <div className="flex flex-col gap-2.5 bg-slate-50 border border-slate-150 rounded-2xl p-4 shadow-inner">
                  <div className="flex items-center justify-between">
                    <label className="font-caption text-slate-500 uppercase tracking-wider text-[10px] font-bold">Assign Lead Washer</label>
                    <span className="font-micro text-[10px] text-blue-650 font-bold bg-blue-100/60 px-2.5 py-0.5 rounded-full">REQUIRED</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    {washers.map((w) => {
                      const isSelected = selectedWasherId === w.id;
                      return (
                        <button
                          key={w.id}
                          type="button"
                          onClick={() => setSelectedWasherId(w.id)}
                          className={`p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition-all outline-none focus:outline-none cursor-pointer ${
                            isSelected 
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                              : 'bg-white text-slate-700 border-slate-200/50 hover:bg-slate-50/50'
                          }`}
                        >
                          <div className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {w.name.split(' ').map(n=>n[0]).join('')}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-title-small text-[11px] font-bold truncate leading-tight">{w.name}</p>
                            <p className={`font-micro text-[9px] mt-0.5 truncate leading-tight ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                              {w.role}
                            </p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Action button triggers */}
                <div className="flex flex-col gap-2 mt-2">
                  <button 
                    onClick={handleConfirmArrival}
                    className="w-full bg-blue-600 text-white font-title-medium text-center py-4 rounded-xl hover:bg-blue-700 shadow-md shadow-blue-100 cursor-pointer active:scale-[0.98] transition-all"
                  >
                    Check In Patient (Arrival)
                  </button>
                  <button 
                    onClick={() => setVerifiedBooking(null)}
                    className="w-full bg-white border border-slate-200 text-slate-500 font-title-medium text-center py-3 rounded-xl hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel & Close Registry
                  </button>
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* SUBMODAL 1: CONFIGURE SERVICES AND PRICING */}
        <AnimatePresence>
          {showServicesModal && (
            <div className="absolute inset-0 z-50 flex flex-col justify-end">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => {
                  setShowServicesModal(false);
                  setEditingServiceId(null);
                }}
                className="absolute inset-0 bg-black/60 backdrop-blur-xs"
              />
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 220 }}
                className="relative bg-white rounded-t-[2.5rem] p-5 flex flex-col gap-4.5 shadow-2xl z-10 select-none pb-8 max-h-[85%] overflow-y-auto hide-scrollbar"
              >
                <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto -mt-1.5"></div>
                
                <div className="flex items-center justify-between border-b border-slate-50 pb-2.5">
                  <div>
                    <h2 className="font-caption text-slate-800 font-extrabold text-[14px] tracking-wide uppercase">SERVICE PLANS & CATALOG</h2>
                    <p className="font-body-small text-[11px] text-slate-500 mt-0.5">Revoke, add, or customize active catalog prices</p>
                  </div>
                  <button 
                    onClick={() => {
                      setShowServicesModal(false);
                      setEditingServiceId(null);
                    }}
                    className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold hover:bg-slate-200 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {/* Edit Service form or static services list */}
                <div className="flex flex-col gap-3 max-h-[280px] overflow-y-auto hide-scrollbar">
                  {services.map((svc) => {
                    const isEditing = editingServiceId === svc.id;
                    return (
                      <div key={svc.id} className="bg-slate-50 border border-slate-100 rounded-2xl p-3.5 flex flex-col gap-2.5">
                        {isEditing ? (
                          // Edit Form
                          <div className="flex flex-col gap-2 font-sans">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-[10px] font-bold text-slate-500">Service Name</label>
                                <input 
                                  type="text" 
                                  value={svc.name}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setServices(prev => prev.map(s => s.id === svc.id ? { ...s, name: val } : s));
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 font-semibold"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] font-bold text-slate-500">Price (KSh)</label>
                                <input 
                                  type="number" 
                                  value={svc.price}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value) || 0;
                                    setServices(prev => prev.map(s => s.id === svc.id ? { ...s, price: val } : s));
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 font-semibold"
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-[10px] font-bold text-slate-500">Duration (Mins)</label>
                                <input 
                                  type="number" 
                                  value={svc.duration}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value) || 0;
                                    setServices(prev => prev.map(s => s.id === svc.id ? { ...s, duration: val } : s));
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 font-semibold"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] font-bold text-slate-500">Brief Description</label>
                                <input 
                                  type="text" 
                                  value={svc.description}
                                  onChange={(e) => {
                                    const val = e.target.value;
                                    setServices(prev => prev.map(s => s.id === svc.id ? { ...s, description: val } : s));
                                  }}
                                  className="w-full bg-white border border-slate-200 rounded-lg p-2 text-xs text-slate-800 font-semibold"
                                />
                              </div>
                            </div>
                            <button 
                              onClick={() => {
                                setEditingServiceId(null);
                                showToast(`✓ '${svc.name}' updated!`, "success");
                              }}
                              className="mt-1 w-full bg-blue-600 text-white rounded-lg py-1.5 text-xs font-bold hover:bg-blue-700 cursor-pointer"
                            >
                              Save Service Edits
                            </button>
                          </div>
                        ) : (
                          // Default Card View
                          <div className="flex items-start justify-between">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <h4 className="font-title-medium text-slate-800 font-bold">{svc.name}</h4>
                                <span className="bg-blue-50 text-blue-600 font-micro text-[10px] font-bold px-2 py-0.5 rounded-full">
                                  ⏱ {svc.duration}m
                                </span>
                              </div>
                              <p className="font-body-small text-[11px] text-slate-400 mt-1 line-clamp-1">{svc.description}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="font-black text-xs text-slate-700 whitespace-nowrap">KES {svc.price}</span>
                              <div className="flex gap-1">
                                <button
                                  onClick={() => setEditingServiceId(svc.id)}
                                  className="w-7 h-7 rounded-lg bg-blue-50 hover:bg-blue-100 flex items-center justify-center text-blue-650 transition-colors cursor-pointer text-xs"
                                  title="Edit Price"
                                >
                                  📝
                                </button>
                                <button
                                  onClick={() => {
                                    if (services.length <= 1) {
                                      showToast("Cannot delete the last available service!", "error");
                                      return;
                                    }
                                    if (confirm(`Remove '${svc.name}' from active catalog?`)) {
                                      setServices(prev => prev.filter(s => s.id !== svc.id));
                                      showToast(`✓ Removed '${svc.name}'`, "success");
                                    }
                                  }}
                                  className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-650 transition-colors cursor-pointer"
                                >
                                  🗑
                                </button>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Subform to create a fresh custom Service Plan */}
                <div className="border-t border-slate-100 pt-3 flex flex-col gap-2 font-sans">
                  <div className="flex items-center justify-between">
                    <p className="font-caption text-slate-850 font-black text-[11px] tracking-wide uppercase">Add a New Wash Plan</p>
                    <span className="text-[10px] text-blue-600 font-bold bg-blue-50 px-2 py-0.5 rounded-full">CATALOG REGISTER</span>
                  </div>
                  
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const fd = new FormData(form);
                    const name = (fd.get('svc_name') as string || '').trim();
                    const price = parseInt(fd.get('svc_price') as string) || 0;
                    const duration = parseInt(fd.get('svc_duration') as string) || 0;
                    const desc = (fd.get('svc_desc') as string || '').trim();

                    if (!name || price <= 0 || duration <= 0) {
                      showToast("Please fully define service name, price & duration", "error");
                      return;
                    }

                    const newPlan: ServicePlan = {
                      id: 'SVC_' + Date.now(),
                      name,
                      price,
                      duration,
                      description: desc || 'Pro wash care'
                    };

                    setServices(prev => [...prev, newPlan]);
                    showToast(`✓ Registered service '${name}' in Mombasa catalog!`, "success");
                    form.reset();
                  }} className="flex flex-col gap-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input 
                        name="svc_name"
                        type="text" 
                        required
                        placeholder="Service Name" 
                        className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-450 font-semibold"
                      />
                      <input 
                        name="svc_price"
                        type="number" 
                        required
                        placeholder="Price (KES)" 
                        className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-450 font-semibold"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <input 
                        name="svc_duration"
                        type="number" 
                        required
                        placeholder="Duration (Mins)" 
                        className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-450 font-semibold"
                      />
                      <input 
                        name="svc_desc"
                        type="text" 
                        placeholder="Brief Description" 
                        className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-450 font-semibold"
                      />
                    </div>
                    <button 
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white rounded-xl py-3 text-xs font-bold transition-all shadow-sm cursor-pointer"
                    >
                      + Save & Append Catalog Item
                    </button>
                  </form>
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* SUBMODAL 2: STAFF ROSTER & CREW MONITOR */}
        <AnimatePresence>
          {showWashersModal && (
            <div className="absolute inset-0 z-50 flex flex-col justify-end">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowWashersModal(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-xs"
              />
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 220 }}
                className="relative bg-white rounded-t-[2.5rem] p-5 flex flex-col gap-4.5 shadow-2xl z-10 select-none pb-8 max-h-[85%] overflow-y-auto hide-scrollbar"
              >
                <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto -mt-1.5"></div>
                
                <div className="flex items-center justify-between border-b border-slate-50 pb-2.5">
                  <div>
                    <h2 className="font-caption text-slate-800 font-extrabold text-[14px] tracking-wide uppercase">STAFF ROSTERS & MONITOR</h2>
                    <p className="font-body-small text-[11px] text-slate-500 mt-0.5">Manage active washers and field shift duties</p>
                  </div>
                  <button 
                    onClick={() => setShowWashersModal(false)}
                    className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold hover:bg-slate-200 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {/* Washer lists */}
                <div className="flex flex-col gap-2.5 max-h-[290px] overflow-y-auto hide-scrollbar">
                  {washers.map((w) => (
                    <div key={w.id} className="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-xs ${w.avatarColor}`}>
                          {w.name.split(' ').map(n=>n[0]).join('')}
                        </div>
                        <div>
                          <h4 className="font-title-medium text-slate-800 font-bold">{w.name}</h4>
                          <span className="text-[10px] text-slate-400 font-medium font-body-small">{w.role}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full whitespace-nowrap">
                          🟢 ON DUTY
                        </span>
                        <button 
                          onClick={() => {
                            if (washers.length <= 1) {
                              showToast("Cannot remove the last active staff on shift!", "error");
                              return;
                            }
                            if (confirm(`Revoke duty shift from ${w.name}?`)) {
                              setWashers(prev => prev.filter(member => member.id !== w.id));
                              showToast(`✓ Removed ${w.name} from duty roster`, "info");
                            }
                          }}
                          className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 text-red-650 flex items-center justify-center transition-colors cursor-pointer"
                        >
                          ✕
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Staff Creation section */}
                <div className="border-t border-slate-100 pt-3.5 flex flex-col gap-2.5 font-sans">
                  <p className="font-caption text-slate-800 font-black text-[11px] tracking-wide uppercase">Register New Operator Staff</p>
                  
                  <div className="flex flex-col gap-2">
                    <input 
                      type="text" 
                      placeholder="Full Name (e.g. Paul Mwangi)"
                      value={newStaffName}
                      onChange={(e) => setNewStaffName(e.target.value)}
                      className="bg-slate-50 border border-slate-205 rounded-xl p-2.5 text-xs text-slate-800 placeholder-slate-400 font-semibold"
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <select 
                        value={newStaffRole}
                        onChange={(e) => setNewStaffRole(e.target.value)}
                        className="bg-slate-50 border border-slate-205 rounded-xl p-2.5 text-xs text-slate-800 font-semibold"
                      >
                        <option value="Exterior Specialist">Exterior Specialist</option>
                        <option value="Detailing Specialist">Detailing Specialist</option>
                        <option value="Senior Inspector">Senior Inspector</option>
                        <option value="General Crew">General Crew</option>
                      </select>
                      <button 
                        onClick={() => {
                          const sanitized = newStaffName.trim();
                          if (!sanitized) {
                            showToast("Please enter a valid staff name!", "error");
                            return;
                          }
                          const colors = ["bg-blue-600", "bg-purple-600", "bg-emerald-600", "bg-indigo-650", "bg-amber-600"];
                          const randomColor = colors[Math.floor(Math.random() * colors.length)];
                          
                          const newCrew: Washer = {
                            id: 'W_' + Date.now(),
                            name: sanitized,
                            role: newStaffRole,
                            avatarColor: randomColor
                          };

                          setWashers(prev => [...prev, newCrew]);
                          showToast(`✓ Added ${sanitized} to Mombasa shift crew!`, "success");
                          setNewStaffName('');
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
                      >
                        + Add To Roster
                      </button>
                    </div>
                  </div>
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* SUBMODAL 3: OPERATOR SUBSCRIPTION CENTER & BILLING ENGINE */}
        <AnimatePresence>
          {showSubscriptionModal && (
            <div className="absolute inset-0 z-50 flex flex-col justify-end">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowSubscriptionModal(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-xs"
              />
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 220 }}
                className="relative bg-slate-900 rounded-t-[2.5rem] p-5 flex flex-col gap-4 text-white shadow-2xl z-10 select-none pb-8 max-h-[85%] overflow-y-auto hide-scrollbar border-t border-slate-800"
              >
                <div className="w-12 h-1.5 bg-slate-800 rounded-full mx-auto -mt-1.5"></div>
                
                <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                  <div className="font-sans">
                    <h2 className="font-caption text-amber-400 font-extrabold text-[13px] tracking-wide uppercase">OPERATOR BILLING & REVENUE</h2>
                    <p className="font-body-small text-[10px] text-slate-400 mt-0.5">SaaS tiers & customer app transaction offsets</p>
                  </div>
                  <button 
                    onClick={() => setShowSubscriptionModal(false)}
                    className="w-7 h-7 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-bold hover:bg-slate-700 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                {/* Info summary card header */}
                <div className="bg-gradient-to-r from-blue-700/25 via-indigo-650/20 to-blue-700/25 border border-blue-500/20 rounded-2xl p-4 text-center font-sans">
                  <span className="inline-flex items-center gap-1 bg-blue-500/20 text-blue-300 px-3 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider mb-2 font-micro">
                    ⚡ FLEXIBLE PLAN OPTIONS
                  </span>
                  <p className="text-xs font-bold text-white">Optimize Your Depot Revenue Splits</p>
                  <p className="text-[10px] text-slate-350 mt-1 leading-relaxed">
                    Choose the plan that suits you. Lower your platform commission splits by switching to monthly subscription tiers!
                  </p>
                </div>

                {/* Sub Plan Selection Tiers */}
                <div className="flex flex-col gap-2.5">
                  <p className="font-caption text-slate-400 text-[10px] uppercase tracking-wider font-bold font-sans">Select Operator SaaS Plan</p>
                  
                  {[
                    {
                      id: 'Starter',
                      title: 'Starter',
                      price: 'KES 0 / mo',
                      commission: '20% commission cut',
                      features: ['No monthly commitment', 'Standard basic analytics', 'Up to 3 active staff roster', 'All-around support'],
                      badge: 'Zero Subscription'
                    },
                    {
                      id: 'Growth',
                      title: 'Growth Plan',
                      price: 'KES 1,499 / mo',
                      commission: '10% commission cut',
                      features: ['Save on active commissions', 'Advanced weekly trends', 'Up to 8 active staff roster', 'Priority support line'],
                      badge: 'Standard Tier'
                    },
                    {
                      id: 'Pro',
                      title: 'Pro Plan ⭐',
                      price: 'KES 2,999 / mo',
                      commission: '0% commission (Recommended)',
                      features: ['No commission splits (Keep 100%)', 'Full access & unlimited staff', 'Deep business insights report', '24/7 dedicated desk support'],
                      badge: 'Recommended'
                    }
                  ].map((tier) => {
                    const isSelected = operatorPlan === tier.id;
                    return (
                      <div 
                        key={tier.id}
                        onClick={() => {
                          setOperatorPlan(tier.id as any);
                          showToast(`✓ Subscribed to ${tier.title}!`, "success");
                        }}
                        className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-left flex flex-col gap-2 relative ${
                          isSelected 
                            ? 'bg-blue-600 border-blue-500 text-white shadow-lg' 
                            : 'bg-white/5 border-white/5 text-slate-200 hover:bg-white/10'
                        }`}
                      >
                        <div className="flex items-center justify-between font-sans">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-title-medium text-xs font-bold leading-tight">{tier.title}</h4>
                            </div>
                            <div className="flex items-baseline gap-1.5 mt-0.5">
                              <p className={`text-[12px] font-black ${isSelected ? 'text-white' : 'text-blue-400'}`}>
                                {tier.price}
                              </p>
                              <span className="text-[9px] text-slate-400 font-medium">({tier.commission})</span>
                            </div>
                          </div>
                          <span className={`text-[8px] font-extrabold font-micro px-2 py-0.5 rounded-full ${
                            isSelected ? 'bg-white text-blue-600' : 'bg-slate-800 text-slate-350'
                          }`}>
                            {tier.badge}
                          </span>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-x-3 gap-y-1 mt-1 border-t border-white/5 pt-2">
                          {tier.features.map((feat, i) => (
                            <div key={i} className="flex items-start gap-1 font-sans text-[9px] text-slate-300 leading-tight">
                              <span className="text-emerald-400 text-[10px]">✓</span>
                              <span className="truncate">{feat}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Commission Breakdown Details */}
                <div className="bg-white/5 border border-white/5 rounded-2xl p-3.5 font-sans">
                  <div className="flex items-center gap-2 mb-2 font-sans">
                    <span className="text-rose-400 text-sm">✂</span>
                    <h4 className="text-rose-400 font-extrabold text-[10px] tracking-wider uppercase font-micro">PASSENGER APP BOOKINGS OVERFLOW</h4>
                  </div>
                  <p className="text-[10.5px] text-slate-350 leading-relaxed font-sans">
                    To connect you with drivers automatically, a platform commission is automatically applied depending on your active SaaS tier. 
                  </p>
                  <p className="text-[10.5px] text-slate-400 leading-relaxed mt-1 font-sans">
                    Walk-ins, bypass guests, and manual logs at the depot trigger <strong>KSh 0</strong> commission under all active SaaS operators.
                  </p>
                </div>

                {/* Submodal Actions */}
                <div className="flex flex-col gap-2 mt-2 font-sans">
                  <button 
                    onClick={() => setShowSubscriptionModal(false)}
                    className="w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white rounded-xl py-3 text-xs font-bold text-center transition-all shadow-md shadow-blue-500/20 cursor-pointer border-0 outline-none"
                  >
                    Confirm & Return
                  </button>
                </div>

              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}

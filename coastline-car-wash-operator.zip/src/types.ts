export interface Booking {
  id: string;
  user_name: string;
  initials: string;
  plate: string;
  time: string;
  amount: number;
  status: 'Confirmed' | 'In Progress' | 'Completed' | 'Overdue';
  plan: string; // Dynamic service plan name
  duration: number; // in minutes
  assignedWasherId?: string;
  washStartedAt?: string; // ISO date string
}

export interface ServicePlan {
  id: string;
  name: string;
  price: number; // in KES
  duration: number; // in minutes
  description: string;
}

export interface Washer {
  id: string;
  name: string;
  role: string;
  avatarColor: string;
}

export interface Transaction {
  id: string;
  user_name: string;
  type: string;
  amount: number;
  time: string;
  date: string;
}

export interface WashStep {
  id: string;
  title: string;
  category: 'prep' | 'wash' | 'dry' | 'inspect';
}

export interface InflowSettings {
  totalBays: number;
  avgDuration: number;
}
